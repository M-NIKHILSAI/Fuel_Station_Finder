let map;
let markers = [];
let infoWindow;
let currentLat = 28.6139; // Default Delhi
let currentLng = 77.2090; // Default Delhi
let activeStationId = null;
let trafficLayer = null;
// DOM Elements
const btnDetectLocation = document.getElementById('btn-detect-location');
const btnMockLocation = document.getElementById('btn-mock-location');
const selectSort = document.getElementById('sort-select');
const selectFilter = document.getElementById('filter-select');
const stationListEl = document.getElementById('station-list');
const loadingIndicator = document.getElementById('loading-indicator');
const mapAlert = document.getElementById('map-alert');
const mapAlertText = document.getElementById('map-alert-text');

const stationModal = document.getElementById('station-modal');
const btnCloseModal = document.getElementById('btn-close-modal');
const modalStationName = document.getElementById('modal-station-name');
const modalStationAddress = document.getElementById('modal-station-address');
const modalStationHours = document.getElementById('modal-station-hours');
const modalStationWait = document.getElementById('modal-station-wait');
const modalPricePetrol = document.getElementById('modal-price-petrol');
const modalPriceDiesel = document.getElementById('modal-price-diesel');
const modalAmenities = document.getElementById('modal-amenities');

// Modal Close logic
if (btnCloseModal) btnCloseModal.addEventListener('click', () => stationModal.classList.add('hidden'));
if (stationModal) stationModal.addEventListener('click', (e) => {
    if (e.target === stationModal) stationModal.classList.add('hidden');
});

// Initialize App
function initMap() {
    // If API key is missing, initMap might not be called by Google SDK, 
    // but if it is called, we setup the map.
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: currentLat, lng: currentLng },
        zoom: 13,
        mapTypeControl: false,
        streetViewControl: false,
        styles: [
            // Custom minimal map style to fit premium UI
            { featureType: "poi", elementType: "labels", stylers: [{ visibility: "off" }] },
            { featureType: "transit", elementType: "labels", stylers: [{ visibility: "off" }] }
        ]
    });
    
    infoWindow = new google.maps.InfoWindow();

    // Initial fetch
    fetchStations();
}

// Fallback init in case Google Maps SDK fails to load due to missing Key
document.addEventListener('DOMContentLoaded', () => {
    // We add a tiny delay to see if initMap triggered via SDK
    setTimeout(() => {
        if (typeof google === 'undefined' || !map) {
            showAlert("Google Maps Key needed for map rendering. Data list still active.");
            fetchStations();
        }
    }, 2000);
});

btnDetectLocation.addEventListener('click', () => {
    if (navigator.geolocation) {
        btnDetectLocation.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Locating...';
        navigator.geolocation.getCurrentPosition(
            (position) => {
                currentLat = position.coords.latitude;
                currentLng = position.coords.longitude;
                btnDetectLocation.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i> Current Location';
                if(map) map.setCenter({ lat: currentLat, lng: currentLng });
                fetchStations();
                showAlert("Location updated");
            },
            () => {
                btnDetectLocation.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i> Current Location';
                showAlert("Location access denied or failed.");
            }
        );
    } else {
        showAlert("Geolocation not supported by browser.");
    }
});

btnMockLocation.addEventListener('click', () => {
    currentLat = 28.6139;
    currentLng = 77.2090;
    if(map) map.setCenter({ lat: currentLat, lng: currentLng });
    fetchStations();
    showAlert("Using mock location (New Delhi)");
});

selectSort.addEventListener('change', fetchStations);
selectFilter.addEventListener('change', fetchStations);

const toggleTraffic = document.getElementById('toggle-traffic');
if (toggleTraffic) {
    toggleTraffic.addEventListener('change', (e) => {
        if (!map) return;
        if (e.target.checked) {
            if (!trafficLayer) {
                trafficLayer = new google.maps.TrafficLayer();
            }
            trafficLayer.setMap(map);
            showAlert("Traffic layer enabled");
        } else {
            if (trafficLayer) {
                trafficLayer.setMap(null);
            }
            showAlert("Traffic layer disabled");
        }
    });
}


async function fetchStations() {
    showLoading(true);
    stationListEl.innerHTML = '';
    
    const sortBy = selectSort.value;
    const filterBy = selectFilter.value;
    const url = `/api/stations?lat=${currentLat}&lng=${currentLng}&sort_by=${sortBy}&filter_by=${filterBy}`;

    try {
        const response = await fetch(url);
        const json = await response.json();
        
        if (json.status === 'success') {
            renderList(json.data);
            renderMarkers(json.data);
        } else {
            console.error("Error formatting stations:", json.message);
            showAlert("Error fetching stations.");
        }
    } catch (error) {
        console.error("Fetch error:", error);
        showAlert("Network error fetching stations.");
    } finally {
        showLoading(false);
    }
}

function renderList(stations) {
    stationListEl.innerHTML = '';
    
    if (stations.length === 0) {
        stationListEl.innerHTML = '<li style="text-align:center;color:#64748b;padding:2rem;">No stations found.</li>';
        return;
    }

    stations.forEach(station => {
        const li = document.createElement('li');
        li.className = `station-card ${activeStationId === station.id ? 'active' : ''}`;
        li.dataset.id = station.id;
        
        const isAvailable = station.available;
        const statusClass = isAvailable ? 'available' : 'unavailable';
        const statusText = isAvailable ? 'Available' : 'No Fuel';

        li.innerHTML = `
            <div class="card-header">
                <span class="station-name">${station.name}</span>
                <span class="station-distance">${station.distance} km</span>
            </div>
            <div class="prices">
                <div class="price-item">
                    <div class="price-type">Petrol</div>
                    <div class="price-value">₹${station.petrol_price.toFixed(2)}</div>
                </div>
                <div class="price-item">
                    <div class="price-type">Diesel</div>
                    <div class="price-value">₹${station.diesel_price.toFixed(2)}</div>
                </div>
            </div>
            <div class="card-footer">
                <div class="status ${statusClass}">
                    <div class="status-dot"></div>
                    ${statusText}
                </div>
                <div class="wait-time-badge">
                    <i class="fa-regular fa-clock"></i> ${station.wait_time} min wait
                </div>
                <div style="font-size: 0.8rem; color: #3b82f6;">View Details <i class="fa-solid fa-arrow-right"></i></div>
            </div>
        `;

        li.addEventListener('click', () => {
            document.querySelectorAll('.station-card').forEach(el => el.classList.remove('active'));
            li.classList.add('active');
            activeStationId = station.id;
            
            openModal(station);
            
            // Trigger marker click if map exists
            const marker = markers.find(m => m.stationId === station.id);
            if (marker && map && map.setCenter) {
                try {
                    map.setCenter(marker.getPosition());
                    map.setZoom(15);
                    google.maps.event.trigger(marker, 'click');
                } catch(e) {}
            }
        });

        stationListEl.appendChild(li);
    });
}

function renderMarkers(stations) {
    if (!map) return; // Google Maps not loaded
    
    // Clear old markers
    markers.forEach(m => m.setMap(null));
    markers = [];

    // Add user location marker
    const userMarker = new google.maps.Marker({
        position: { lat: currentLat, lng: currentLng },
        map: map,
        icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: "#3b82f6",
            fillOpacity: 1,
            strokeWeight: 2,
            strokeColor: "#ffffff"
        },
        title: "Your Location"
    });
    markers.push(userMarker);

    // Add station markers
    stations.forEach(station => {
        const marker = new google.maps.Marker({
            position: { lat: station.lat, lng: station.lng },
            map: map,
            title: station.name,
            icon: {
                url: station.available ? 'http://maps.google.com/mapfiles/ms/icons/red-dot.png' : 'http://maps.google.com/mapfiles/ms/icons/ltblue-dot.png'
            }
        });
        marker.stationId = station.id;

        marker.addListener('click', () => {
            const content = `
                <div style="padding: 10px; font-family: Inter, sans-serif; min-width: 150px;">
                    <h3 style="margin: 0 0 5px 0; font-size: 1.1rem; color: #1e293b;">${station.name}</h3>
                    <p style="margin: 0; color: #64748b;">Petrol: ₹${station.petrol_price.toFixed(2)}</p>
                    <p style="margin: 0; color: #64748b;">Diesel: ₹${station.diesel_price.toFixed(2)}</p>
                    <p style="margin: 5px 0 0 0; font-weight: 600; color: #d97706;"><i class="fa-regular fa-clock"></i> ${station.wait_time} min wait</p>
                    <p style="margin: 5px 0 0 0; font-weight: 600; color: #3b82f6;">${station.distance} km away</p>
                </div>
            `;
            infoWindow.setContent(content);
            infoWindow.open(map, marker);
            
            // Highlight in list
            activeStationId = station.id;
            const li = document.querySelector(`.station-card[data-id="${station.id}"]`);
            if (li) {
                document.querySelectorAll('.station-card').forEach(el => el.classList.remove('active'));
                li.classList.add('active');
                li.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        });

        markers.push(marker);
    });
}

function showLoading(show) {
    if (show) {
        loadingIndicator.classList.remove('hidden');
        stationListEl.classList.add('hidden');
    } else {
        loadingIndicator.classList.add('hidden');
        stationListEl.classList.remove('hidden');
    }
}

function showAlert(msg) {
    mapAlertText.textContent = msg;
    mapAlert.classList.remove('hidden');
    setTimeout(() => {
        mapAlert.classList.add('hidden');
    }, 4000);
}

function openModal(station) {
    if (!stationModal) return;
    
    modalStationName.textContent = station.name;
    modalStationAddress.textContent = station.address || "Address unavailable";
    modalStationHours.textContent = station.hours || "Hours unavailable";
    modalStationWait.textContent = `${station.wait_time} min wait`;
    
    modalPricePetrol.textContent = `₹${station.petrol_price.toFixed(2)}`;
    modalPriceDiesel.textContent = `₹${station.diesel_price.toFixed(2)}`;
    
    // Render amenities
    modalAmenities.innerHTML = '';
    if (station.amenities && station.amenities.length > 0) {
        station.amenities.forEach(amenity => {
            const span = document.createElement('span');
            span.className = 'amenity-tag';
            span.textContent = amenity;
            modalAmenities.appendChild(span);
        });
    } else {
        modalAmenities.innerHTML = '<span class="amenity-tag" style="background:#f1f5f9;color:#64748b;">No extra amenities</span>';
    }
    
    stationModal.classList.remove('hidden');
}
